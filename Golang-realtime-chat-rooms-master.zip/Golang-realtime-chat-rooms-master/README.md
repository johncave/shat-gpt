# Golang-realtime-chat-rooms

### Start the server
`go run *.go`
 
http://localhost:8080/room/1
